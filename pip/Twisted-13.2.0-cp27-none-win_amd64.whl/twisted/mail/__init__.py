
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""

Twisted Mail: a Twisted E-Mail Server.

Maintainer: Jp Calderone

"""

from twisted.mail._version import version
__version__ = version.short()
