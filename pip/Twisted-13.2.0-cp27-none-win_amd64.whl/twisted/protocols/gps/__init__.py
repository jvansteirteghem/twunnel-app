"""Global Positioning System protocols."""
