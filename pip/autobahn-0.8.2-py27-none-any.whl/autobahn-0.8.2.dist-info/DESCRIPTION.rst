Autobahn|Python is a network library implementing

 * The WebSocket Protocol
 * The Web Application Messaging Protocol (WAMP)

for Twisted and Asyncio on Python 2 and 3.

Autobahn|Python is part of the Autobahn project:

The Autobahn project provides open-source implementations of the
WebSocket and WAMP protocols. WebSocket allows bidirectional real-time
messaging on the Web and WAMP adds asynchronous Remote Procedure Calls
and Publish & Subscribe on top of WebSocket.

More information:

 * https://github.com/tavendo/AutobahnPython/blob/master/README.md
 * http://autobahn.ws/python
 * http://wamp.ws

Source code:

 * https://github.com/tavendo/AutobahnPython


